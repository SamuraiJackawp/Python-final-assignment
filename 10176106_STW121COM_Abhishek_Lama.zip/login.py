def myfun(indict):
    x=list(indict.key())
    for key in x:
        value=indict[key]
        try:
            indict[value]=key
        except  TypeError:
            print("valis asdfdhgfsd")

    return indict
print(myfun({"seeses":"asdas"}))
